from cmu_graphics import *

from utility import iso_to_screen_staggered

LOGIC_TILE_WIDTH = 128
LOGIC_TILE_HEIGHT = 64  # Tiled 中的逻辑瓦片高度

def clearScreen(app):
    drawRect(0, 0, app.width, app.height, fill='black')

def renderMap(app, tileToDraw, cameraOffsetX, cameraOffsetY):
    for tileInfo in sorted(tileToDraw, key=lambda tileInfo: (tileInfo[1], tileInfo[0])):

        mapX, mapY, tileImage, tileImagePixelWidth, tileImagePixelHeight = tileInfo
        screenX, screenY = iso_to_screen_staggered(mapX, mapY, LOGIC_TILE_WIDTH, LOGIC_TILE_HEIGHT,
                                                     cameraOffsetX, cameraOffsetY)
        blitX = screenX
        blitY = screenY - (tileImagePixelHeight - LOGIC_TILE_HEIGHT)

        if -tileImagePixelWidth < blitX < app.width + tileImagePixelWidth and \
                -tileImagePixelHeight < blitY < app.height + tileImagePixelHeight:
            #print(f"Drawing tile at ({blitX}, {blitY})")
            drawImage(tileImage, blitX, blitY)
