from cmu_graphics import *
from views.RenderUtility import *
from models.MapLoader import GameMap
from models.DataManager import loadData
from models.EntityManager import loadEntity

from controllers.MouseControl import keyUpdate, mouseUpdate

from views.Creature import *
from views.Zombie import *

def onAppStart(app):
    app.title = "2.5D Pygame Example with Camera (Tiled Isometric Staggered + CSV)"
    app.stepsPerSecond = 120

    loadData(app)
    loadEntity(app)

    app.cameraOffsetX = -(400-64)
    app.cameraOffsetY = -(300-64)

def onStep(app):

    # Update entities
    # models.EntityManager.mainCharacter.update()
    # models.EntityManager.mainCharacter.draw(app)

    # Handle mouse and keyboard input
    # mouseUpdate()
    pass

def redrawAll(app):
    clearScreen(app)

    renderMap(app, app.map.tileToDraw, app.cameraOffsetX, app.cameraOffsetY)
    renderMap(app, app.decor.tileToDraw, app.cameraOffsetX, app.cameraOffsetY)
    #renderMap(app, app.house.tileToDraw, app.cameraOffsetX, app.cameraOffsetY)
    #renderMap(app, app.roof.tileToDraw, app.cameraOffsetX, app.cameraOffsetY)

def onKeyHold(app, key):
    # Handle key presses
    if key == 'Escape':
        app.stop()
    keyUpdate(app, key)

def onMouseMove(app, x, y):
    # Handle mouse movement
    pass        

runApp(height=600, width=800)